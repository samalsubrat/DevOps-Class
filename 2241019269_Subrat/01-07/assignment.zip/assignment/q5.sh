#!/bin/bash
grep -n "ERROR" "$1"
